import React from 'react'

export default function AccountManager() {
  return (
    <div>AccountManager</div>
  )
}
